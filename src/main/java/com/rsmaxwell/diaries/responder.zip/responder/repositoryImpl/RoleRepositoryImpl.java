package com.rsmaxwell.diaries.responder.repositoryImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.rsmaxwell.diaries.responder.dto.RoleDTO;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.repository.RoleRepository;
import com.rsmaxwell.diaries.responder.utilities.WhereBuilder;

import jakarta.persistence.EntityManager;

public class RoleRepositoryImpl extends AbstractCrudRepository<Role, RoleDTO, Long> implements RoleRepository {

	public RoleRepositoryImpl(EntityManager entityManager) {
		super(entityManager);
	}

	@Override
	public String getTable() {
		return "role";
	}

	@Override
	public String getKeyField() {
		return "id";
	}

	@Override
	public <S extends Role> String getKeyValue(S entity) {
		return entity.getId().toString();
	}

	@Override
	public <S extends Role> void setKeyValue(S entity, Object value) {
		entity.setId((Long) value);
	}

	@Override
	public List<String> getFields() {
		List<String> list = new ArrayList<String>();
		list.add("name");
		return list;
	}

	@Override
	public <S extends Role> List<Object> getValues(S entity) {
		List<Object> list = new ArrayList<Object>();
		list.add(entity.getName());
		return list;
	}

	@Override
	public RoleDTO newDTO(Object[] result) {
		Long id = getLongFromSqlResult(result, 0, null);
		String name = getStringFromSqlResult(result, 1, null);
		Long version = 0L;

		//@formatter:off
		return RoleDTO.builder()
				.id(id)
				.name(name)
				.version(version)
				.build();
		//@formatter:on
	}

	@Override
	public Optional<RoleDTO> findByName(String name) {

		// @formatter:off
		String where = new WhereBuilder()
				.add("name", name)
				.build();
		// @formatter:on

		List<RoleDTO> list = new ArrayList<RoleDTO>();
		for (RoleDTO x : find(where)) {
			list.add(x);
		}

		return singleItem(list);
	}
}