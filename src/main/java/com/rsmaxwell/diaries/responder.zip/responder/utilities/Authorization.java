package com.rsmaxwell.diaries.responder.utilities;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.SecretKey;

import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

public class Authorization {

	private static final Logger log = LoggerFactory.getLogger(Authorization.class);

	public static String getToken(String secret, String subject, int expiration, ChronoUnit units) {

		Map<String, Object> claims = new HashMap<String, Object>();

		return getTokenWithClaims(secret, subject, expiration, units, claims);
	}

	public static String getTokenWithClaims(String secret, String subject, int expiration, ChronoUnit units, Map<String, Object> claims) {

		Instant now = Instant.now();
		Date expireTime = Date.from(now.plus(expiration, units));

		byte[] secretBytes = Base64.getDecoder().decode(secret);
		SecretKey secretKey = Keys.hmacShaKeyFor(secretBytes);

		String jwt = null;
		try {
			// @formatter:off
			    JwtBuilder builder = Jwts.builder()
					.subject(subject)
			        .expiration(expireTime)
			        .signWith(secretKey);
				// @formatter:on

			for (String key : claims.keySet()) {
				Object value = claims.get(key);
				builder.claim(key, value);
			}

			jwt = builder.compact();

		} catch (Throwable t) {
			log.error("Unhandled exception while handling request", t);
		}

		return jwt;
	}

	public static Claims parseToken(String secret, String token) throws ExpiredJwtException {

		byte[] secretBytes = Base64.getDecoder().decode(secret);
		SecretKey key = Keys.hmacShaKeyFor(secretBytes);

		//@formatter:off
		return Jwts.parser()
				.verifyWith(key)
				.build()
				.parseSignedClaims(token)
				.getPayload();
		//@formatter:on
	}

	public static String getRefreshToken(Map<String, Object> args) {

		log.info("Authorization.getRefreshToken");

		Object value = args.get("refreshToken");
		if (value == null) {
			log.info("Authorization.getRefreshToken: refreshToken not found");
			return null;
		}

		String refreshToken = null;
		if (value instanceof String) {
			refreshToken = (String) value;
		} else {
			log.info("Authorization.getRefreshToken: refreshToken is an unexpected type: " + value.getClass().getName());
			return null;
		}

		return refreshToken;
	}

	public static String getAccessToken(List<UserProperty> userProperties) {

		log.info("Authorization.getAccessToken");

		String accessToken = null;
		for (UserProperty property : userProperties) {
			if ("accessToken".equals(property.getKey())) {
				accessToken = property.getValue();
				break;
			}
		}
		if (accessToken == null) {
			log.info("Authorization.getAccessToken: accessToken not found'");
			return null;
		}

		return accessToken;
	}

	public static Claims checkToken(DiaryContext context, String subject, String token) {

		log.info("Authorization.checkToken");

		if (token == null) {
			log.info("Authorization.checkToken: accessToken not found'");
			return null;
		}

		Claims claims = null;
		try {
			String secret = context.getSecret();
			claims = parseToken(secret, token);
		} catch (ExpiredJwtException e) {
			log.info("Authorization.checkToken: JWT has expired'");
			// log.catching(e);
			return null;
		}

		String actual = claims.getSubject();
		if (!subject.equals(actual)) {
			log.info(String.format("Authorization.checkToken: unexpected subject: expected: %s, actual: %s", subject, actual));
			return null;
		}

		return claims;
	}

	public static void main(String[] args) throws Exception {

		String secret = "p8l4Qk6gw6QIvNo0uqZNyAsExRPxH7a7fW4Bz0MUk0w=";
		String subject = "access";
		Integer id20 = 123456;
		int expirationPeriod = 5;

		Map<String, Object> claims1 = new HashMap<String, Object>();
		claims1.put("id20", id20);

		String accessToken = getTokenWithClaims(secret, subject, expirationPeriod, ChronoUnit.SECONDS, claims1);

		DiaryContext context = new DiaryContext();
		context.setSecret(secret);

		Claims claims2 = checkToken(context, subject, accessToken);

		if (claims2 == null) {
			System.out.println("Unauthorized");
		} else {
			Integer id = claims2.get("id20", Integer.class);

			if (id == id20) {
				System.out.println("Success");
			} else {
				System.out.println(String.format("Failed. Expected %d actual %d", id20, id));
			}
		}

	}
}
