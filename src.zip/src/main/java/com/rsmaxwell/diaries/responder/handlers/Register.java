package com.rsmaxwell.diaries.responder.handlers;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.mindrot.jbcrypt.BCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber.PhoneNumber;
import com.rsmaxwell.diaries.responder.dto.PersonDTO;
import com.rsmaxwell.diaries.responder.model.Person;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.model.UserStatus;
import com.rsmaxwell.diaries.responder.repository.PersonRepository;
import com.rsmaxwell.diaries.responder.utilities.DiaryContext;
import com.rsmaxwell.diaries.responder.utilities.Field;
import com.rsmaxwell.mqtt.rpc.common.Response;
import com.rsmaxwell.mqtt.rpc.exceptions.RpcStatusException;
import com.rsmaxwell.mqtt.rpc.responder.RequestHandler;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class Register extends RequestHandler {

	private static final Logger log = LoggerFactory.getLogger(Register.class);
	public static final PhoneNumberUtil phoneNumberUtil = PhoneNumberUtil.getInstance();
	public static final String defaultRegion = "GB";

	@Override
	public Response handleRequest(Object ctx, Map<String, Object> args, List<UserProperty> userProperties) throws Exception {
		log.trace("Entering method");

		DiaryContext context = (DiaryContext) ctx;
		PersonRepository personRepository = context.getPersonRepository();

		Person person = validate(personRepository, args);

		EntityManager entityManager = context.getEntityManager();
		EntityTransaction tx = null;
		try {
			tx = entityManager.getTransaction();
			tx.begin();

			entityManager.persist(person);

			tx.commit();

			log.info(String.format("Person Registered: %s", person));

			return Response.success(person.getId());

		} catch (Exception e) {
			log.error("Unhandled exception while handling request", e);
			if (tx != null) {
				tx.rollback();
			}
			throw RpcStatusException.badRequest(e.getMessage());
		}
	}

	private Person validate(PersonRepository personRepository, Map<String, Object> args) throws Exception {

		String username = new Field("username", args).min(3).max(20).toString();
		String password = new Field("password", args).min(3).max(20).toString();
		String firstname = new Field("firstname", args).min(3).max(20).toString();
		String lastname = new Field("lastname", args).min(3).max(20).toString();
		String knownas = new Field("knownas", args).min(3).max(20).toString();
		String email = new Field("email", args).email().toString();
		String phone = new Field("phone", args).phone().toString();

		Optional<PersonDTO> optional = personRepository.findByUsername(username);
		if (optional.isPresent()) {
			throw RpcStatusException.badRequest("Already Registered");
		}

		String passwordHash = BCrypt.hashpw(password, BCrypt.gensalt());

		PhoneNumber phoneNumber = null;
		try {
			phoneNumber = phoneNumberUtil.parse(phone, defaultRegion);
		} catch (Exception e) {
			throw RpcStatusException.badRequest("Not a valid phone number");
		}
		int countryCode = phoneNumber.getCountryCode();
		long nationalNumber = phoneNumber.getNationalNumber();

		UserStatus status = UserStatus.PENDING;
		Role role = null;

		return new Person(username, passwordHash, firstname, lastname, knownas, email, countryCode, nationalNumber, status, role);
	}
}
