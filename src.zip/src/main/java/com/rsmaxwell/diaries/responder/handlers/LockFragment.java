package com.rsmaxwell.diaries.responder.handlers;

import java.net.HttpURLConnection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.eclipse.paho.mqttv5.client.MqttAsyncClient;
import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsmaxwell.diaries.responder.dto.FragmentPublishDTO;
import com.rsmaxwell.diaries.responder.dto.MarqueeDBDTO;
import com.rsmaxwell.diaries.responder.model.Fragment;
import com.rsmaxwell.diaries.responder.model.LockInfo;
import com.rsmaxwell.diaries.responder.model.Marquee;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.repository.FragmentRepository;
import com.rsmaxwell.diaries.responder.repository.MarqueeRepository;
import com.rsmaxwell.diaries.responder.utilities.Authorization;
import com.rsmaxwell.diaries.responder.utilities.DiaryContext;
import com.rsmaxwell.mqtt.rpc.common.Response;
import com.rsmaxwell.mqtt.rpc.common.Utilities;
import com.rsmaxwell.mqtt.rpc.exceptions.RpcStatusException;
import com.rsmaxwell.mqtt.rpc.responder.RequestHandler;

import io.jsonwebtoken.Claims;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class LockFragment extends RequestHandler {

	private static final Logger log = LoggerFactory.getLogger(LockFragment.class);
	static private ObjectMapper mapper = new ObjectMapper();

	@Override
	public Response handleRequest(Object ctx, Map<String, Object> args, List<UserProperty> userProperties) throws Exception {

		log.info("LockFragment.handleRequest: args: " + mapper.writeValueAsString(args));

		String accessToken = Authorization.getAccessToken(userProperties);
		DiaryContext context = (DiaryContext) ctx;
		Claims claims = Authorization.checkToken(context, "access", accessToken);
		Authorization.checkActive(claims);
		Authorization.checkRoleAtLeast(claims, Role.EDITOR);
		log.info("LockFragment.handleRequest: Authorization.check: OK!");

		FragmentRepository fragmentRepository = context.getFragmentRepository();
		MarqueeRepository marqueeRepository = context.getMarqueeRepository();

		EntityManager em = context.getEntityManager();
		EntityTransaction tx = em.getTransaction();

		Fragment fragment;

		tx.begin();
		try {

			// get the incoming Fragment ID and inflate it
			Long id = Utilities.getLong(args, "id");
			fragment = context.inflateFragment(id);

			// get the fields needed to make the lock
			Long userId = claims.get("userId", Long.class);
			String username = claims.get("username", String.class);
			String knownAs = claims.get("knownAs", String.class);
			String sessionId = claims.get("sessionId", String.class);

			// Ensure lock object exists
			LockInfo lock = fragment.getLock();
			if (lock == null) {
				lock = new LockInfo();
				fragment.setLock(lock);
			}

			// Prevent stealing someone else’s lock
			if (lock.isLocked()) {
				boolean lockedByMe = lock.isLockedBy(userId, sessionId);
				boolean stale = lock.isStale(now, ttl);

				if (!lockedByMe && !stale) {
					throw RpcStatusException.conflict("Fragment is locked by another user.");
				}

				if (stale) {
					log.info("LockFragment.handleRequest: replacing stale lock on fragment {} held by userId={}, sessionId={}, timestamp={}", fragment.getId(),
							lock.getLockUserId(), lock.getLockSessionId(), lock.getLockTimeStamp());
				}
			}

			// Lock the fragment
			lock.lockNow(userId, username, knownAs, sessionId);

			// save to database
			int count = fragmentRepository.update(fragment);
			if (count != 1) {
				log.info("LockFragment.handleRequest: number of records updated: {}", count);
			}
			tx.commit();

		} catch (RpcStatusException e) {
			if (tx.isActive()) {
				tx.rollback();
			}

			if (e.getStatus().getCode() == HttpURLConnection.HTTP_CONFLICT) {
				log.info("LockFragment.handleRequest: lock rejected: {}", e.getMessage());
			} else {
				log.warn("LockFragment.handleRequest: RPC request rejected: {}", e.getMessage());
			}

			throw e;
		} catch (Exception e) {
			log.error("LockFragment.handleRequest: unexpected error; rolling back", e);
			if (tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}

		// get the Marquee associated with the fragment (can be null)
		Marquee marquee = null;
		Optional<MarqueeDBDTO> optionalMarqueeDTO = marqueeRepository.findByFragment(fragment);
		if (optionalMarqueeDTO.isPresent()) {
			MarqueeDBDTO marqueeDTO = optionalMarqueeDTO.get();
			marquee = context.inflateMarquee(marqueeDTO);
		}

		// publish the locked Fragment to the topic tree
		MqttAsyncClient client = context.getPublisherClient();
		log.info("LockFragment.handleRequest: publishing the locked fragment to the TopicTree");
		FragmentPublishDTO dto = new FragmentPublishDTO(fragment, marquee);
		dto.publish(client);

		return Response.success(fragment.getId());
	}
}
