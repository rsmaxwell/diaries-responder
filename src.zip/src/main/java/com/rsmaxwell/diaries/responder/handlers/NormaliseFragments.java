package com.rsmaxwell.diaries.responder.handlers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.eclipse.paho.mqttv5.client.MqttAsyncClient;
import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsmaxwell.diaries.responder.dto.FragmentDBDTO;
import com.rsmaxwell.diaries.responder.dto.FragmentPublishDTO;
import com.rsmaxwell.diaries.responder.dto.MarqueeDBDTO;
import com.rsmaxwell.diaries.responder.model.Fragment;
import com.rsmaxwell.diaries.responder.model.Marquee;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.repository.FragmentRepository;
import com.rsmaxwell.diaries.responder.repository.MarqueeRepository;
import com.rsmaxwell.diaries.responder.utilities.Authorization;
import com.rsmaxwell.diaries.responder.utilities.DiaryContext;
import com.rsmaxwell.mqtt.rpc.common.Response;
import com.rsmaxwell.mqtt.rpc.common.Utilities;
import com.rsmaxwell.mqtt.rpc.exceptions.RpcStatusException;
import com.rsmaxwell.mqtt.rpc.responder.RequestHandler;

import io.jsonwebtoken.Claims;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class NormaliseFragments extends RequestHandler {

	private static final Logger log = LoggerFactory.getLogger(NormaliseFragments.class);
	static private ObjectMapper mapper = new ObjectMapper();

	@Override
	public Response handleRequest(Object ctx, Map<String, Object> args, List<UserProperty> userProperties) throws Exception {

		log.info("NormaliseFragments.handleRequest");

		String accessToken = Authorization.getAccessToken(userProperties);
		DiaryContext context = (DiaryContext) ctx;
		Claims claims = Authorization.checkToken(context, "access", accessToken);
		Authorization.checkActive(claims);
		Authorization.checkRoleAtLeast(claims, Role.EDITOR);
		log.info("NormaliseFragments.handleRequest: Authorization.check: OK!");

		MqttAsyncClient client = context.getPublisherClient();
		FragmentRepository fragmentRepository = context.getFragmentRepository();
		MarqueeRepository marqueeRepository = context.getMarqueeRepository();

		log.info("NormaliseFragments.handleRequest: get the date arguments");

		Integer year;
		Integer month;
		Integer day;
		try {
			year = Utilities.getInteger(args, "year");
			month = Utilities.getInteger(args, "month");
			day = Utilities.getInteger(args, "day");

		} catch (Exception e) {
			log.info("NormaliseFragments.handleRequest: args: " + mapper.writeValueAsString(args));
			throw RpcStatusException.badRequest(e.getMessage());
		}

		EntityManager em = context.getEntityManager();
		EntityTransaction tx = em.getTransaction();

		List<Fragment> updates = new ArrayList<>();

		BigDecimal sequence = new BigDecimal("1.0000");
		BigDecimal increment = new BigDecimal("1.0000");

		tx.begin();
		try {
			for (FragmentDBDTO fragmentDTO : fragmentRepository.findAllByDate(year, month, day)) {
				BigDecimal currentSeq = fragmentDTO.getSequence();

				if (currentSeq != null && currentSeq.compareTo(sequence) == 0) {
					// log.info(String.format("fragment id:%d, already has correct sequence number: %s", fragmentDTO.getId(), sequence.toPlainString()));
				} else {
					String currentSeqStr = (currentSeq != null) ? currentSeq.toPlainString() : "null";
					log.info(String.format("Updating fragment id: %d, sequence: %s -> %s", fragmentDTO.getId(), currentSeqStr, sequence.toPlainString()));

					Fragment fragment = context.inflateFragment(fragmentDTO);

					fragment.setSequence(sequence);
					fragment.incrementVersion();
					fragmentRepository.update(fragment);
					updates.add(fragment);
				}

				sequence = sequence.add(increment);
			}
			tx.commit();

		} catch (Exception ex) {
			tx.rollback();
			throw ex;
		}

		// Publish the updates
		for (Fragment fragment : updates) {
			// @formatter:off
			log.info(String.format("Publishing fragment %d:%d:%d - %d --> sequence: %s",
					fragment.getYear(), fragment.getMonth(), fragment.getDay(), fragment.getId(),
					fragment.getSequence().toPlainString()));
			// @formatter:on

			Optional<MarqueeDBDTO> optionalMarqueeDTO = marqueeRepository.findByFragmentId(fragment.getId());
			MarqueeDBDTO marqueeDTO = null;
			if (optionalMarqueeDTO.isPresent()) {
				marqueeDTO = optionalMarqueeDTO.get();
			}

			Marquee marquee = context.inflateMarquee(marqueeDTO);
			FragmentPublishDTO fragmentPublishDTO = new FragmentPublishDTO(fragment, marquee);

			fragmentPublishDTO.publish(client);
		}

		return Response.success(updates.size());
	}
}
