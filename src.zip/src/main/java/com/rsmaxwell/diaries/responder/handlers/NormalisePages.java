package com.rsmaxwell.diaries.responder.handlers;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.eclipse.paho.mqttv5.client.MqttAsyncClient;
import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.rsmaxwell.diaries.responder.dto.PageDTO;
import com.rsmaxwell.diaries.responder.model.Diary;
import com.rsmaxwell.diaries.responder.model.Page;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.repository.PageRepository;
import com.rsmaxwell.diaries.responder.utilities.Authorization;
import com.rsmaxwell.diaries.responder.utilities.DiaryContext;
import com.rsmaxwell.mqtt.rpc.common.Response;
import com.rsmaxwell.mqtt.rpc.responder.RequestHandler;

import io.jsonwebtoken.Claims;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class NormalisePages extends RequestHandler {

	private static final Logger log = LoggerFactory.getLogger(NormalisePages.class);

	@Override
	public Response handleRequest(Object ctx, Map<String, Object> args, List<UserProperty> userProperties) throws Exception {

		log.info("NormalisePages.handleRequest");

		String accessToken = Authorization.getAccessToken(userProperties);
		DiaryContext context = (DiaryContext) ctx;
		Claims claims = Authorization.checkToken(context, "access", accessToken);
		Authorization.checkActive(claims);
		Authorization.checkRoleAtLeast(claims, Role.EDITOR);
		log.info("NormalisePages.handleRequest: Authorization.check: OK!");

		MqttAsyncClient client = context.getPublisherClient();
		PageRepository pageRepository = context.getPageRepository();

		EntityManager em = context.getEntityManager();
		EntityTransaction tx = em.getTransaction();

		List<Page> updates = new ArrayList<>();

		BigDecimal sequence = new BigDecimal("1.0000");
		BigDecimal increment = new BigDecimal("1.0000");

		tx.begin();
		try {
			for (PageDTO pageDTO : pageRepository.findAll()) {
				BigDecimal currentSeq = pageDTO.getSequence();

				if (currentSeq != null && currentSeq.compareTo(sequence) == 0) {
					// log.info(String.format("diary id:%d, name:%s already has correct sequence number", dto.getId(), dto.getName()));
				} else {
					String currentSeqStr = (currentSeq != null) ? currentSeq.toPlainString() : "null";
					log.info(String.format("Updating page id: %d, name: %s, sequence: %s --> %s", pageDTO.getId(), pageDTO.getName(), currentSeqStr, sequence.toPlainString()));

					Diary diary = context.inflateDiary(pageDTO.getDiaryId());
					Page page = new Page(diary, pageDTO);

					page.setSequence(sequence);
					page.incrementVersion();
					pageRepository.update(page);
					updates.add(page);
				}

				sequence = sequence.add(increment);
			}
			tx.commit();

		} catch (Exception ex) {
			tx.rollback();
			throw ex;
		}

		// Publish the updates
		for (Page page : updates) {
			log.info(String.format("Publishing page id:%d, name:%s --> sequence: %s", page.getId(), page.getName(), page.getSequence().toPlainString()));
			PageDTO dto = new PageDTO(page);
			dto.publish(client);
		}

		return Response.success(updates.size());
	}
}
