package com.rsmaxwell.diaries.responder.handlers;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.eclipse.paho.mqttv5.client.MqttAsyncClient;
import org.eclipse.paho.mqttv5.common.packet.UserProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rsmaxwell.diaries.responder.dto.PageDTO;
import com.rsmaxwell.diaries.responder.model.Diary;
import com.rsmaxwell.diaries.responder.model.Page;
import com.rsmaxwell.diaries.responder.model.Role;
import com.rsmaxwell.diaries.responder.repository.PageRepository;
import com.rsmaxwell.diaries.responder.utilities.Authorization;
import com.rsmaxwell.diaries.responder.utilities.DiaryContext;
import com.rsmaxwell.mqtt.rpc.common.Response;
import com.rsmaxwell.mqtt.rpc.common.Utilities;
import com.rsmaxwell.mqtt.rpc.exceptions.RpcStatusException;
import com.rsmaxwell.mqtt.rpc.responder.RequestHandler;

import io.jsonwebtoken.Claims;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class UpdatePage extends RequestHandler {

	private static final Logger log = LoggerFactory.getLogger(UpdatePage.class);
	static private ObjectMapper mapper = new ObjectMapper();

	@Override
	public Response handleRequest(Object ctx, Map<String, Object> args, List<UserProperty> userProperties) throws Exception {

		log.info("UpdatePage.handleRequest: args: " + mapper.writeValueAsString(args));

		String accessToken = Authorization.getAccessToken(userProperties);
		DiaryContext context = (DiaryContext) ctx;
		Claims claims = Authorization.checkToken(context, "access", accessToken);
		Authorization.checkActive(claims);
		Authorization.checkRoleAtLeast(claims, Role.EDITOR);
		log.info("UpdatePage.handleRequest: Authorization.check: OK!");

		PageRepository pageRepository = context.getPageRepository();

		EntityManager em = context.getEntityManager();
		EntityTransaction tx = em.getTransaction();

		Page incomingPage;
		Page originalPage;

		tx.begin();
		try {
			Long id = Utilities.getLong(args, "id");
			Long version = Utilities.getLong(args, "version");
			BigDecimal sequence = Utilities.getBigDecimal(args, "sequence");
			Long diaryId = Utilities.getLong(args, "diaryId");
			String name = Utilities.getString(args, "name");
			String extension = Utilities.getString(args, "extension");
			Integer width = Utilities.getInteger(args, "width");
			Integer height = Utilities.getInteger(args, "height");

			// (1) get the original Page
			originalPage = context.inflatePage(id);

			// (2) get the incoming Page

			//@formatter:off
			PageDTO pageDTO = PageDTO.builder()
					.id(id)
					.version(version)
					.sequence(sequence)
					.diaryId(diaryId)
					.name(name)
					.extension(extension)
					.width(width)
					.height(height)
					.build();
			//@formatter:on

			Diary incomingDiary = context.inflateDiary(diaryId);
			incomingPage = new Page(incomingDiary, pageDTO);

			// (3) check and bump the version
			incomingPage.checkAndIncrementVersion(originalPage);

			// (4) save to database
			int count = pageRepository.update(incomingPage);
			if (count != 1) {
				log.info("UpdatePage.handleRequest: number of records updated: {}", count);
			}
			tx.commit();

		} catch (RpcStatusException e) {
			log.warn("UpdatePage.handleRequest: request failed; rolling back transaction: {}", e.getMessage(), e);
			if (tx.isActive()) {
				tx.rollback();
			}
			throw e;
		} catch (Exception e) {
			log.error("UpdatePage.handleRequest: unexpected error; rolling back transaction", e);
			if (tx.isActive()) {
				tx.rollback();
			}
			throw e;
		}

		// (5) Remove the original page from the TopicTree
		MqttAsyncClient client = context.getPublisherClient();
		if (originalPage.keyFieldsChanged(incomingPage)) {
			log.info("Updatepage.handleRequest: removing the original page from the TopicTree");
			PageDTO dto = new PageDTO(originalPage);
			dto.remove(client);
		}

		// (6) publish the Page to the topic tree
		PageDTO dto = new PageDTO(incomingPage);
		dto.publish(client);

		return Response.success(incomingPage.getId());
	}
}
