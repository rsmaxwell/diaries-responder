# diaries-response

## Topic tree



request
reply
diaries					-> list of diary names
pages/{diary id}		-> list of page names